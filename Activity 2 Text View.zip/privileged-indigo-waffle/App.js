import React, {useState} from 'react';
import {Text, StyleSheet} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const TextInANest = () => {
  const [titleText, setTitleText] = useState("Sombrador, Jhon Paul");
  const bodyText = 'Libis bukid elena apartment number 3 yung gate may kalawang Malinta Valenzuela City 21 years old My favorite food is adobo sinigang menudo My hobbies is playing basketball and online gamesHAHAHAH .';
  

  const onPressTitle = () => {
    setTitleText("Paul Sombrador [pressed]");
  };

  return (
    <SafeAreaProvider>
      <SafeAreaView style={styles.container}>
        <Text style={styles.baseText}> 
          <Text style={styles.titleText} onPress={onPressTitle}>
            {titleText}
            {'\n'}
            {'\n'}
          </Text>
          <Text numberOfLines={5}>{bodyText}</Text>
        </Text>
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  baseText: {
    fontWeight: 'Cochin',
    textAlign: 'center'
  },
  titleText: {
    fontSize: 20,
    fontWeight: 'bold',
    
  },
});

export default TextInANest;

