import React from 'react';
import {Text, StyleSheet} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const BoldAndBeautiful = () => (
  <SafeAreaProvider>
    <SafeAreaView style={styles.container}>
      <Text style={styles.baseText}>
        Sombrador, 
        <Text style={styles.innerText}> Jhon Paul</Text>
      </Text>
      <Text style={styles.innerText}> Libis bukid elena apartment number 3 yung gate may kalawang Malinta Valenzuela City 21 years old My favorite food is adobo sinigang menudo My hobbies is playing basketball and online gamesHAHAHAH</Text>
       <Text style={styles.innerText}> blue</Text>
    </SafeAreaView>
  </SafeAreaProvider>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    
  },
  baseText: {
    fontWeight: 'bold',
    textAlign: 'center'    
  },
  innerText: {
    color: 'red',
    textAlign: 'center'
  },
});

export default BoldAndBeautiful;